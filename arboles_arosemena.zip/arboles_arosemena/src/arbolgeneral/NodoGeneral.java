package arbolgeneral;

public class NodoGeneral {
    int dato;
    NodoGeneral primerHijo;
    NodoGeneral hermano;
    NodoGeneral padre;

    public NodoGeneral(int dato) {
        this.dato = dato;
        this.primerHijo = null;
        this.hermano = null;
        this.padre = null;
    }

    public int contarHijos() {
        int count = 0;
        NodoGeneral aux = this.primerHijo;
        while (aux != null) {
            count++;
            aux = aux.hermano;
        }
        return count;
    }
}